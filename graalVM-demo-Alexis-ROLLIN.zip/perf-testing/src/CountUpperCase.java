public class CountUpperCase {

    static final int ITERATIONS = 1;
    static final int SUB_ITERATIONS = 10_000_000;
    
    public static void main(String[] args) {
        String sentence = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        
        long total_time=0;
        int modulo = SUB_ITERATIONS /10;
        
        for (int iter = 0; iter < ITERATIONS; iter++) {
            if (ITERATIONS != 1) System.out.println("-- iteration " + (iter + 1) + " --");
            
            long total=0, start = System.currentTimeMillis(), last = start;
            for (int i = 1; i < SUB_ITERATIONS; i++) {
                total += sentence.chars().filter(Character::isUpperCase).count();
                if (i % modulo == 0) {
                    long now = System.currentTimeMillis();
                    System.out.printf("%d (%d ms)%n", i / 1_000_000, now - last);
                    total_time += now-last;
                    last = now;
                }
            }
            System.out.printf("total: %d (%d ms) %n", total, System.currentTimeMillis() - start);
        }
        System.out.printf("total time: %d ms", total_time);
    }
}