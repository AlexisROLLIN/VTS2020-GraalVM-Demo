power <- function(x, y) {
	print(" Power function in power.r")
	return (x ^ y)
}
