import java.io.File;
import java.io.IOException;

import org.graalvm.polyglot.*;

public class Main {
	
    static Context context = Context.newBuilder().allowAllAccess(true).build();
	
	/* Utils */

    // Used to process a file in another language
    static Value loadProg(String language, String fileName) throws IOException {
        File file = new File(fileName);
        Source source = Source.newBuilder(language, file).build();
        return context.eval(source);
    }
    
    //In Javascript
    static int add(int x, int y) throws IOException {

        loadProg("js", "src/add.js");
        Value addJs= context.getBindings("js").getMember("add");
        int res = (addJs.execute(x, y)).asInt();
        return res;
    }
    
    //In Python
    static int multiply(int x, int y) throws IOException {

        loadProg("python", "src/multiply.py");
        Value multPy = context.getBindings("python").getMember("multiply");
        int res = (multPy.execute(x, y)).asInt();
        return res;
    }
    
    //In R
    static int power(int x, int y) throws IOException {

        loadProg("R", "src/power.r");
        Value powerR = context.getBindings("R").getMember("power");
        int res = (powerR.execute(x, y)).asInt();
        return res;
    }
	
    /* Main */
    public static void main(String[] args) throws IOException {
    	
        int res = power(multiply(add(1,4),2),2); //((1+4)*2)^2
        System.out.println("Resultat = "+res);
    	
        

    }
}