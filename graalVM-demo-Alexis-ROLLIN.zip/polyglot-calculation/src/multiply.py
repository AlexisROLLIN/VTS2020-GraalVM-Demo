#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  2 14:13:00 2020

@author: alexis
"""

def multiply(x,y):
	print(" Multiply function in multiply.py")
	return x*y



