function add(x, y){
    print(" Add function in add.js")
    return x+y;
}